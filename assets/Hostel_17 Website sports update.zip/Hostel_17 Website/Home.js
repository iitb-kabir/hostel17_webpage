document.addEventListener('DOMContentLoaded', () => {
    // Event Showcase Tabs
    const eventTabsContainer = document.getElementById('event-tabs');
    if (eventTabsContainer) {
        const eventTabButtons = eventTabsContainer.querySelectorAll('.event-tab-button');
        eventTabButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active styles and ARIA attributes from all buttons
                eventTabButtons.forEach(btn => {
                    btn.classList.remove('bg-white', 'text-teal-600', 'shadow-sm');
                    btn.classList.add('text-gray-500');
                    btn.setAttribute('aria-selected', 'false');
                    btn.setAttribute('tabindex', '-1');
                });

                // Add active styles and ARIA attributes to the clicked button
                button.classList.add('bg-white', 'text-teal-600', 'shadow-sm');
                button.classList.remove('text-gray-500');
                button.setAttribute('aria-selected', 'true');
                button.removeAttribute('tabindex');
            });
        });
    }

    // Feedback Portal Type Buttons
    const feedbackButtonsContainer = document.getElementById('feedback-type-buttons');
    if (feedbackButtonsContainer) {
        const feedbackTypeButtons = feedbackButtonsContainer.querySelectorAll('.feedback-type-button');
        feedbackTypeButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active styles and ARIA attribute from all buttons
                feedbackTypeButtons.forEach(btn => {
                    btn.classList.remove('bg-teal-50', 'text-teal-600');
                    btn.classList.add('bg-gray-100', 'text-gray-600', 'hover:bg-gray-200');
                    btn.removeAttribute('aria-pressed');
                });
                
                // Add active styles and ARIA attribute to the clicked button
                button.classList.add('bg-teal-50', 'text-teal-600');
                button.classList.remove('bg-gray-100', 'text-gray-600', 'hover:bg-gray-200');
                button.setAttribute('aria-pressed', 'true');
            });
        });
    }
});