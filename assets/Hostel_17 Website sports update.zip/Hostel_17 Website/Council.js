document.addEventListener('DOMContentLoaded', () => {
    const subNavTabs = document.querySelectorAll('#sub-nav .nav-tab');

    subNavTabs.forEach(tab => {
        tab.addEventListener('click', (event) => {
            // Remove active classes from all tabs
            subNavTabs.forEach(t => {
                t.classList.remove('bg-teal-50', 'text-teal-600', 'font-semibold');
                t.classList.add('text-gray-500', 'hover:bg-gray-100');
            });

            // Add active classes to the clicked tab
            const clickedTab = event.currentTarget;
            clickedTab.classList.add('bg-teal-50', 'text-teal-600', 'font-semibold');
            clickedTab.classList.remove('text-gray-500', 'hover:bg-gray-100');
            
            // Note: The smooth scrolling is handled by the `scroll-behavior: smooth` in CSS
            // and the `href="#section-id"` in the HTML. No extra JS is needed for that.
        });
    });
});
